<?php
    /*$database = [
        "host" => "localhost",
        "username" => "dwes_manana",
        "password" => "dwes_2024",
        "db" => "dwes_manana_tenistas"
    ];
    */
    $database = [
        "host" => "localhost",
        "username" => "root",

        "db" => "dwes_manana_tenistas"
    ];
    
?>
