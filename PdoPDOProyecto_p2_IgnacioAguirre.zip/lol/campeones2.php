<?php 

try {
    $mysql = "mysql:host=localhost;dbname=lol;charset=UTF8";
    $user = "root";
    $conexion = new PDO($mysql, $user);
    
    $resultado = $conexion->query('SELECT * FROM campeon');
    echo "<table border='1'>";
echo
"<tr><th>ID</th><th>Nombre</th><th>Rol</th><th>Dificultad</th><th>Descripcion</th><th>Editar</th><th>Borrar</th></tr>";
// tendrás que añadir un foreache o similar


    foreach ($registro = $resultado->fetchAll(pdo::FETCH_ASSOC) as $registro) {
        echo "<tr>";
        echo "<td>".$registro['id']."</td>";
        echo "<td>".$registro['nombre']."</td>";
        echo "<td> ".$registro['rol']."</td>";
        echo "<td>".$registro['dificultad']."</td>";
        echo "<td>".$registro['descripcion']."</td>";
        echo "<td><a href='editando.php?id=".$registro['id']."'>E</a></td>";
        echo "<td><button onclick=".$conexion->exec('DELETE FROM campeon WHERE id='.$registro['id']).">X</button></td>";
        echo "</tr>";
        }
        $conexion = null;
} catch (PDOException $e) {
    echo "<p>" .$e->getMessage()."</p>";
}

?>