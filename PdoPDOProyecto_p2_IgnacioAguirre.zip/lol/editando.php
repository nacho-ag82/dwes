<?php 

try {
    $mysql = "mysql:host=localhost;dbname=lol;charset=UTF8";
    $user = "root";
    $conexion = new PDO($mysql, $user);
    
    $resultado = $conexion->query('SELECT * FROM campeon WHERE id='.$_REQUEST['id']);

    //echo "<form action='confirmar.php?id=".$_REQUEST['id']."' method='POST'>";
    foreach ($registro = $resultado->fetchAll(pdo::FETCH_ASSOC) as $registro) {
        echo "ID: ".$registro['id'];
        echo "NOMBRE: <input type='text' name='nombre'".$registro['nombre']."</input>";
        echo "ROL: <input type='text' name='rol'".$registro['rol']."</input>";
        echo "DIFICULTAD (f,m,d): <input type='text' name='dificultad'".$registro['dificultad']."</input>";
        echo "DESCRIPCION: <input type='text' name='descripcion'".$registro['descripcion']."</input>";
        echo "</tr>";
        echo "button type='submit'";
        }
    echo "</form>";
}catch(PDOException $e) {
    echo "<p>" .$e->getMessage()."</p>";
}
?>