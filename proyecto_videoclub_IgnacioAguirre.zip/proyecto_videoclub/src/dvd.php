<?php 
class Dvd{
    public $idiomas;
    private $formatPantalla;
    public function __construct($i,$f) {
        $this->idiomas = $i;
        $this->formatPantalla =$f;
    }

    public function muestraResumen(){
        
    }
}
?>