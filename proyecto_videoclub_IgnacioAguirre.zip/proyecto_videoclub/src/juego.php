<?php 
class Juego{
    public $consola;
    private $minNumJugadores;
    private $maxNumJugadores;

     public function __construct($c, $mi, $ma) {
        $this->consola = $c;
        $this->minNumJugadores = $mi;
        $this->maxNumJugadores = $ma;

    }
    public function muestraJugadoresPosibles(){

    }
    public function muestraResumen(){

    }
}
?>