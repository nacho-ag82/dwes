<?php 
namespace src;
interface Mostrable{
    public function muestraResumen();
}
?>