<?php 
class CintaVideo extends Soporte{
    private $duracion;
    public function __construct($var = null) {
        $this->duracion = $var;
    }
    function muestraResumen(){
        parent::
    }
}
?>