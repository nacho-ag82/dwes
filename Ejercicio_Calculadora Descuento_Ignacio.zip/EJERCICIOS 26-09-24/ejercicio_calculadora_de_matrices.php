<h1>CAlCULADORA DE DESCUENTOS</h1>

<?php
//Declaracion de vriables
$nProducto = "FURBY MORADO LIMPIASUELOS";
$cantidad = 39;
$precioU = 3;
$mensaje;
$totalConDescuento;
$descuento;
//Operacion calculo de precio
$totalSinDescuento = $cantidad*$precioU;


//Condicional para cantidad de descuento
if($totalSinDescuento>50){
    $descuento = $totalSinDescuento*10/100;
}else{
    $descuento = 0;
}
//calculo de precio con descuento
$totalConDescuento = $totalSinDescuento-$descuento;

//condicional tamaño de compra
if ($totalConDescuento>100){
    $mensaje = "Compra grande";
}else{
    $mensaje = "Compra normal";
}
//impresion de resultados
echo "<p>Resumen de compara:</p><p>Nombre de Producto: $nProducto</p><p>Cantidad: $cantidad</p><p>Precio Unitario: $precioU €</p><p>Cantidad: $cantidad</p><p>Total sin descuento: $totalSinDescuento €</p><p>Total con Descuento: $totalConDescuento €</p><p>$mensaje</p>"
?>