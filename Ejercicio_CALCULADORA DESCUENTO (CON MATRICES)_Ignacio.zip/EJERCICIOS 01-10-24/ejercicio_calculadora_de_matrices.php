<h1>CAlCULADORA DE DESCUENTOS CON MATRICES</h1>

<?php
//Declaracion de vriables

$matrizProducto =[["nombre"=> "FURBY MORADO LIMPIASUELOS", "cantidad"=>51,"precioU"=>3],["nombre"=> "FURBY ROSA INUTIL", "cantidad"=>20,"precioU"=>110],["nombre"=> "FURBY VIOLETA", "cantidad"=>100,"precioU"=>0.5]];
define("DESCUENTO_PEQUENO",0);
define("LIMITE_DESCUENTO",50);
define("LIMITE_COMPRA_GRANDE",100);
$mensaje;
$totalConDescuento;
$descuento;

foreach($matrizProducto as $index =>$producto){
    //Operacion calculo de precio
    $totalSinDescuento = $producto["cantidad"]*$producto['precioU'];

    $totalSinDescuento =floatval($totalSinDescuento);

    //Condicional para cantidad de descuento
    if($producto["cantidad"]>LIMITE_DESCUENTO){
        $descuento = $totalSinDescuento*10/100;
    }else{
        $descuento = DESCUENTO_PEQUENO;
    }
    //calculo de precio con descuento
    $totalConDescuento = $totalSinDescuento-$descuento;

    //condicional tamaño de compra
    if ($totalConDescuento>LIMITE_COMPRA_GRANDE){
        $mensaje = "Compra grande";
    }else{
        $mensaje = "Compra normal";
    }
    //impresion de resultados
    $pantalla = "<p>Resumen de compara:\n\nNombre de Producto:". $producto["nombre"]."\nCantidad:".$producto["cantidad"]."\nPrecio Unitario:".(string)number_format($producto['precioU'],2)." €\nTotal sin descuento:". number_format($totalSinDescuento,2)." €\nTotal con Descuento:". number_format($totalConDescuento,2)." €\n$mensaje</p>";
    echo nl2br($pantalla);
}
?>