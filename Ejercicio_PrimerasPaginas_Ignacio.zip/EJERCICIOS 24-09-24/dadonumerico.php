
<h1>Esto es un numero aleatorio del 1 al 6</h1>
<!--Esto es una funcion random, los valores introducidos son los valores minimo y maximo del numor que develve la función-->
<?= rand(1,6)?>