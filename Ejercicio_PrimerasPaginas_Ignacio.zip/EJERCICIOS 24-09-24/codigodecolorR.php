<h1>ESTO ES UN CÓDIGO RGB AL AZAR</h1>
<!--Utilizando la funcion random generamos 3 numeros del 0 al 255 para simular un codigo RGB al azar-->
<?= "R",rand(0,255),"G",rand(0,255),"B",rand(0,255)?>