<h1>BIENVENIDO A LA PÁGINA 2</h1>

<!--Pagina nº2-->
<?= "<h1>¡HOLA MUNDO!</h1>"?>
<?="<a href='holamundo1.php'>esto es un enlace a la pagina 1</a>"?>