<h1>BIENVENIDO A LA PÁGINA 1</h1>

<!--Esta instruccion echo es un enlace que lleva a la pagina nº2-->
<?= "<a href='holamundo2.php'>esto es una enlace a la segunda página</a>"?>