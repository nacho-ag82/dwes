<h1>ESTO ES UN EMOTICONO AL AZAR</h1>

<!--Esta instruccion echo concatenada mostrará un emoticono al azar a traves de la funcion rand()-->
<?= "&#",rand(128512,128586)?>